#!/usr/bin/ruby

arr = ARGV

if ARGV.length < 2
	puts "none"
else
	puts arr.reverse	
end