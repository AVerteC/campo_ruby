#!/usr/bin/ruby
ary =  [2, 8, 9, 48, 8, 22, -12, 2] 
ary2 = ary.map { |e|e + 2  }

puts "#{ary}"
puts "#{ary2}"
